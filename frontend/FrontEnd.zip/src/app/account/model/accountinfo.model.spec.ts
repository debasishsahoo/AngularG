import { Accountinfo } from './accountinfo.model';

describe('Accountinfo', () => {
  it('should create an instance', () => {
    expect(new Accountinfo()).toBeTruthy();
  });
});
