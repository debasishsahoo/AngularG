export class Accountinfo {
}
