const ContactModel = require('../models/contact');

const ContactCTRL = {
    getPosts: async (req, res, next) => { },
    getPostById: async (req, res, next) => { },
    getPostBytime: async (req, res, next) => { },
    createPosts: async (req, res, next) => { },
    updatePosts: async (req, res, next) => { },
    likePosts: async (req, res, next) => { },
    deletePosts: async (req, res, next) => { },
};

module.exports = ContactCTRL;